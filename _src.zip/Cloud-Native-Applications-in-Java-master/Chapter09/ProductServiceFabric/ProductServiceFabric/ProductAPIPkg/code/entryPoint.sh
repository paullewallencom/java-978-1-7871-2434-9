#!/bin/bash
BASEDIR=$(dirname $0)
cd $BASEDIR
java -jar product-0.0.1-SNAPSHOT.jar 
